import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import numpy.random as nr
import math
from sklearn.preprocessing import scale

data=pd.read_csv('weight-height.csv')
cols=['Gender','Height','Weight']

df=pd.DataFrame(data, columns=cols)

cols1=['Height','Weight']
sns.scatterplot(x='Weight',y='Height',hue='Gender',data=data,alpha=0.2)
data_scaled=scale(df[cols1])
data_scaled=pd.DataFrame(data_scaled,columns=cols1)
print(data_scaled.describe().round(3))


genders={'Male':0,'Female':1}
data_scaled['Gender']=[genders[x] for x in data['Gender']]
print(data_scaled.head())




from sklearn.model_selection import train_test_split
import numpy as np
np.random.seed(3456)
data_split = train_test_split(np.asmatrix(data_scaled), test_size = 100)
data_train_features = data_split[0][:, :2]
data_train_labels = np.ravel(data_split[0][:, 2])
data_test_features = data_split[1][:, :2]
data_test_labels = np.ravel(data_split[1][:, 2])
print(data_train_features.shape)
print(data_train_labels.shape)
print(data_test_features.shape)
print(data_test_labels.shape)


input()

from sklearn.neighbors import KNeighborsClassifier
KNN_mod = KNeighborsClassifier(n_neighbors = 3)
KNN_mod.fit(data_train_features, data_train_labels)


input()

data_test = pd.DataFrame(data_test_features, columns = cols1)
data_test['predicted'] = KNN_mod.predict(data_test_features)
data_test['correct'] = [1 if x == z else 0 for x, z in zip(data_test['predicted'], data_test_labels)]
accuracy = 100.0 * float(sum(data_test['correct'])) / float(data_test.shape[0])

print(accuracy)
plt.show()

input()